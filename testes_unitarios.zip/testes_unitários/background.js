// background.js
chrome.runtime.onInstalled.addListener(() => {
    console.log("Extensão 'Teste Unitário' instalada ou atualizada.");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "SAVE_RESULTS") {
        chrome.storage.local.set({ lastTestResults: message.data }, () => {
            sendResponse({ status: "ok" });
        });
        return true;
    } else if (message.type === "GET_RESULTS") {
        chrome.storage.local.get("lastTestResults", (res) => {
            sendResponse({ status: "ok", data: res.lastTestResults || [] });
        });
        return true;
    }
});
