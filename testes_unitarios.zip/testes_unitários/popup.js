document.getElementById("runTests").addEventListener("click", async () => {
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = "<p>Executando testes na página ativa...</p>";

    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const [res] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: collectVisibleComponents
        });

        if (!res || !res.result || res.result.length === 0) {
            resultsDiv.innerHTML = "<p>Não foi possível extrair componentes visíveis da página.</p>";
            return;
        }

        const components = res.result;

        // --- Ortografia via LanguageTool ---
        for (let comp of components) {
            for (let field of comp.fields) {
                if (field.type === "input" || field.type === "button") {
                    try {
                        const response = await fetch("https://api.languagetool.org/v2/check", {
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            body: new URLSearchParams({ text: field.label, language: "pt-BR" })
                        });
                        const result = await response.json();
                        const incorrectWords = result.matches.map(m => m.context.text).filter(w => w.trim() !== "");
                        field.tests.push({
                            test: "Ortografia",
                            result: incorrectWords.length > 0 ? "FAIL" : "PASS",
                            details: incorrectWords.length > 0 ? "Ortografias incorretas: " + incorrectWords.join(", ") : "Ortografia correta"
                        });
                    } catch (e) {
                        field.tests.push({
                            test: "Ortografia",
                            result: "FAIL",
                            details: "Erro ao consultar API"
                        });
                    }
                }
            }
        }

        // --- Alinhamento entre campos ---
        checkFieldAlignment(components);

        // --- Ordem de tabulação ---
        let tabulationCorrect = true;
        for (let comp of components) {
            const inputs = comp.fields.filter(f => f.type === "input" && f.element);
            const focusables = inputs.sort((a, b) => a.element.tabIndex - b.element.tabIndex);
            for (let i = 0; i < focusables.length - 1; i++) {
                const a = focusables[i];
                const b = focusables[i + 1];
                const correct = a.element.tabIndex < b.element.tabIndex;
                a.tests.push({
                    test: `Tabulação para "${b.label}"`,
                    details: correct ? "Ordem correta" : "Ordem incorreta",
                    result: correct ? "PASS" : "FAIL"
                });
                if (!correct) tabulationCorrect = false;
            }
        }

        // --- Mostrar resultados ---
        showComponentResults(components, tabulationCorrect);

    } catch (err) {
        resultsDiv.innerHTML = `<div style="color:red">Erro: ${err.message || err}</div>`;
    }
});

// --- Coleta de componentes visíveis ---
function collectVisibleComponents() {
    function isVisible(el) {
        const style = window.getComputedStyle(el);
        return style.display !== "none" && style.visibility !== "hidden" && el.offsetParent !== null;
    }

    function traverseFrame(doc) {
        const components = [];
        const forms = doc.querySelectorAll('form, [role="form"], div.component-container');

        forms.forEach((form, fidx) => {
            if (!isVisible(form)) return;

            const fields = [];
            let title = form.getAttribute('name') || form.getAttribute('id') || `Componente ${fidx + 1}`;

            // --- Botões ---
            const seenButtons = new Set();
            form.querySelectorAll('button, [role="button"]').forEach((btn, idx) => {
                if (!isVisible(btn)) return;
                const text = (btn.innerText || '').trim() || `sem texto ${idx + 1}`;
                if (!seenButtons.has(text)) {
                    seenButtons.add(text);
                    fields.push({
                        type: "button",
                        label: text,
                        rect: btn.getBoundingClientRect(),
                        tests: [],
                        element: btn
                    });
                }
            });

            // --- Inputs ---
            const seenInputs = new Set();
            form.querySelectorAll('input, [role="textbox"]').forEach((input, idx) => {
                if (!isVisible(input)) return;

                let labelText = "";
                const id = input.id;
                if (id) {
                    const label = form.querySelector(`label[for="${id}"]`);
                    if (label) labelText = label.innerText.trim().replace(/\s*\*$/, '');
                }
                if (!labelText) {
                    labelText = input.getAttribute('placeholder') || `Campo ${idx + 1}`;
                }

                if (!seenInputs.has(labelText)) {
                    seenInputs.add(labelText);

                    // Alinhamento label com input
                    let alignmentTest = [];
                    let relatedLabel = null;
                    if (id) relatedLabel = form.querySelector(`label[for="${id}"]`);
                    else if (input.parentElement && input.parentElement.tagName.toLowerCase() === 'label')
                        relatedLabel = input.parentElement;
                    else {
                        const prev = input.previousElementSibling;
                        if (prev && /label|span|div/i.test(prev.tagName)) relatedLabel = prev;
                    }

                    if (relatedLabel) {
                        const rectInput = input.getBoundingClientRect();
                        const rectLabel = relatedLabel.getBoundingClientRect();
                        const verticalDistance = Math.abs(rectLabel.bottom - rectInput.top);
                        const horizontalDistance = Math.abs(rectLabel.left - rectInput.left);
                        alignmentTest.push({
                            test: "Alinhamento label",
                            result: verticalDistance <= 30 || horizontalDistance <= 30 ? 'PASS' : 'FAIL',
                            details: verticalDistance <= 30 || horizontalDistance <= 30 ? 'Label alinhado corretamente' : 'Label distante do campo'
                        });
                    } else {
                        alignmentTest.push({ test: "Alinhamento label", result: 'FAIL', details: 'Sem label associado' });
                    }

                    fields.push({
                        type: "input",
                        label: labelText,
                        rect: input.getBoundingClientRect(),
                        tests: alignmentTest,
                        element: input
                    });
                }
            });

            components.push({ title, fields });
        });

        // --- Iframes ---
        doc.querySelectorAll('iframe').forEach(frame => {
            try {
                if (frame.contentDocument) {
                    const frameComps = traverseFrame(frame.contentDocument);
                    components.push(...frameComps);
                }
            } catch (e) {
                console.warn("Iframe cross-origin bloqueado:", e);
            }
        });

        return components;
    }

    return traverseFrame(document);
}

// --- Verificação de alinhamento entre campos ---
function checkFieldAlignment(components) {
    const tolerance = 10; // px

    components.forEach(comp => {
        const inputs = comp.fields.filter(f => f.type === "input" && f.rect);

        // Agrupar campos por linha (mesmo top ± tolerance)
        const rows = [];
        inputs.forEach(f => {
            let rowFound = false;
            for (let row of rows) {
                if (Math.abs(row[0].rect.top - f.rect.top) <= tolerance) {
                    row.push(f);
                    rowFound = true;
                    break;
                }
            }
            if (!rowFound) rows.push([f]);
        });

        // Verificar alinhamento horizontal
        rows.forEach(row => {
            if (row.length <= 1) return;
            row.forEach((f, i) => {
                for (let j = i + 1; j < row.length; j++) {
                    const f2 = row[j];
                    const horizontalAligned = Math.abs(f.rect.top - f2.rect.top) <= tolerance;
                    const result = horizontalAligned ? "PASS" : "FAIL";
                    const details = horizontalAligned ? "Alinhamento horizontal correto" : "Campos desalinhados horizontalmente";
                    f.tests.push({ test: `Alinhamento horizontal com "${f2.label}"`, result, details });
                    f2.tests.push({ test: `Alinhamento horizontal com "${f.label}"`, result, details });
                }
            });
        });

        // Agrupar campos por coluna (mesmo left ± tolerance)
        const columns = [];
        inputs.forEach(f => {
            let colFound = false;
            for (let col of columns) {
                if (Math.abs(col[0].rect.left - f.rect.left) <= tolerance) {
                    col.push(f);
                    colFound = true;
                    break;
                }
            }
            if (!colFound) columns.push([f]);
        });

        // Verificar alinhamento vertical
        columns.forEach(col => {
            if (col.length <= 1) return;
            col.forEach((f, i) => {
                for (let j = i + 1; j < col.length; j++) {
                    const f2 = col[j];
                    const verticalAligned = Math.abs(f.rect.left - f2.rect.left) <= tolerance;
                    const result = verticalAligned ? "PASS" : "FAIL";
                    const details = verticalAligned ? "Alinhamento vertical correto" : "Campos desalinhados verticalmente";
                    f.tests.push({ test: `Alinhamento vertical com "${f2.label}"`, result, details });
                    f2.tests.push({ test: `Alinhamento vertical com "${f.label}"`, result, details });
                }
            });
        });
    });
}

// --- Mostrar resultados ---
function showComponentResults(components, tabulationCorrect) {
    const container = document.getElementById("results");
    container.innerHTML = "";

    // --- Informação geral sobre tabulação no topo ---
    const tabDiv = document.createElement("div");
    tabDiv.style.marginBottom = "10px";
    tabDiv.style.fontWeight = "bold";
    tabDiv.style.color = tabulationCorrect ? "green" : "red";
    tabDiv.innerText = `Tabulação: ${tabulationCorrect ? "Correta" : "Incorreta"}`;
    container.appendChild(tabDiv);

    // --- Componentes ---
    components.forEach(comp => {
        const compDiv = document.createElement("div");
        compDiv.style.border = "1px solid #ccc";
        compDiv.style.margin = "10px 0";
        compDiv.style.padding = "5px";

        let html = `<h4>Tela/Formulário: ${comp.title}</h4>`;
        html += `<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr style="background-color:#f0f0f0;">
                            <th>Campo</th>
                            <th>Tipo</th>
                            <th>Teste</th>
                            <th>Detalhes</th>
                            <th>Resultado</th>
                        </tr>
                    </thead>
                    <tbody>`;

        comp.fields.forEach(f => {
            f.tests.forEach(t => {
                html += `<tr>
                            <td>${f.label}</td>
                            <td>${f.type}</td>
                            <td>${t.test}</td>
                            <td>${t.details}</td>
                            <td style="color:${t.result === 'PASS' ? 'green' : 'red'}; font-weight:bold;">${t.result}</td>
                         </tr>`;
            });
        });

        html += `</tbody></table>`;
        compDiv.innerHTML = html;
        container.appendChild(compDiv);
    });
}
